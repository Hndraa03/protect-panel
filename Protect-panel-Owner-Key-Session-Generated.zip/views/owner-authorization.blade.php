@extends('layouts.admin')

@section('title') API Owner Authorization @endsection

@section('content-header')
    <h1>API Owner Authorization<small>Kelola Owner Key dan otorisasi Application API.</small></h1>
@endsection

@section('content')
<div class="row">
    <div class="col-xs-12">
        <div class="box box-primary">
            <div class="box-header with-border"><h3 class="box-title">Owner Key Manager</h3></div>
            <div class="box-body">
                @if (session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
                @if ($errors->has('owner_key'))<div class="alert alert-danger">{{ $errors->first('owner_key') }}</div>@endif

                @if ($isOwner)
                    <div class="alert alert-info">Khusus Owner ID 1: buat atau rotasi Owner Key dari halaman ini. Key lama langsung tidak berlaku dan seluruh sesi API yang sudah diotorisasi akan perlu otorisasi ulang.</div>
                    <form method="POST" action="{{ route('admin.api.owner-authorization.generate') }}" onsubmit="return confirm('Generate Owner Key baru? Key lama dan sesi API sebelumnya akan tidak berlaku.');">
                        {!! csrf_field() !!}
                        <button class="btn btn-warning" type="submit"><i class="fa fa-key"></i> {{ $keyExists ? 'Generate / Rotasi Owner Key' : 'Generate Owner Key' }}</button>
                    </form>
                    @if (session('generated_key'))
                        <div class="form-group" style="margin-top:15px;">
                            <label>Owner Key baru (ditampilkan satu kali)</label>
                            <div class="input-group">
                                <input id="generated-owner-key" type="text" class="form-control" readonly value="{{ session('generated_key') }}">
                                <span class="input-group-btn"><button class="btn btn-primary" type="button" onclick="var e=document.getElementById('generated-owner-key');e.select();document.execCommand('copy');this.innerHTML='Copied';">Copy</button></span>
                            </div>
                            <p class="help-block">Simpan di tempat aman dan bagikan hanya kepada admin yang diberi izin. Hash key disimpan di server; teks asli tidak disimpan.</p>
                        </div>
                    @endif
                @else
                    <div class="alert alert-info">Owner Key hanya dapat dibuat atau dirotasi oleh Admin ID 1. Minta key kepada pemilik panel untuk mengotorisasi sesi ini.</div>
                @endif

                <hr>
                <h4>Status Sesi API</h4>
                @if ($authorized)
                    <div class="alert alert-success">Sesi browser ini sudah diotorisasi. Application API dapat digunakan sampai sesi berakhir, key dirotasi, atau otorisasi dicabut.</div>
                    <form method="POST" action="{{ route('admin.api.owner-authorization.revoke') }}">
                        {!! csrf_field() !!}
                        <button class="btn btn-danger" type="submit">Cabut Otorisasi Sesi</button>
                    </form>
                @else
                    <div class="alert alert-warning">Sesi browser ini belum diotorisasi.</div>
                    <form method="POST" action="{{ route('admin.api.owner-authorization.authorize') }}">
                        {!! csrf_field() !!}
                        <div class="form-group">
                            <label for="owner_key">Owner Key</label>
                            <input id="owner_key" name="owner_key" type="password" class="form-control" required autocomplete="off">
                        </div>
                        <button class="btn btn-primary" type="submit">Otorisasi Sesi</button>
                    </form>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection
