<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Pterodactyl\Http\Controllers\Controller;

class ApiOwnerAuthorizationController extends Controller
{
    private function hashFile(): string
    {
        return storage_path('app/protect-owner-key.sha256');
    }

    private function currentHash(): string
    {
        $file = $this->hashFile();
        return is_file($file) ? trim((string) @file_get_contents($file)) : '';
    }

    public function show(Request $request)
    {
        abort_unless($request->user() && $request->user()->root_admin, 403);
        $hash = $this->currentHash();
        return view('admin.api.owner-authorization', [
            'authorized' => (bool) $request->session()->get('protect_api_authorized', false)
                && (string) $request->session()->get('protect_api_key_hash', '') !== ''
                && $hash !== ''
                && hash_equals($hash, (string) $request->session()->get('protect_api_key_hash', '')),
            'isOwner' => (int) $request->user()->id === 1,
            'keyExists' => $hash !== '',
        ]);
    }

    /** Only Admin ID 1 can generate/rotate the shared Owner Key. */
    public function generate(Request $request)
    {
        abort_unless($request->user() && (int) $request->user()->id === 1, 403);

        $key = rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
        $hash = hash('sha256', $key);
        $file = $this->hashFile();
        $directory = dirname($file);
        if (!is_dir($directory) && !mkdir($directory, 0700, true) && !is_dir($directory)) {
            return back()->withErrors(['owner_key' => 'Folder penyimpanan key tidak dapat dibuat.']);
        }

        $temporary = $file . '.tmp.' . bin2hex(random_bytes(6));
        if (file_put_contents($temporary, $hash . PHP_EOL, LOCK_EX) === false) {
            @unlink($temporary);
            return back()->withErrors(['owner_key' => 'Gagal menyimpan Owner Key. Periksa permission folder storage/app.']);
        }
        @chmod($temporary, 0600);
        if (!@rename($temporary, $file)) {
            @unlink($temporary);
            return back()->withErrors(['owner_key' => 'Gagal mengaktifkan Owner Key baru.']);
        }
        @chmod($file, 0600);

        // Rotating the key invalidates every previously authorized browser session.
        $request->session()->forget(['protect_api_authorized', 'protect_api_authorized_user', 'protect_api_key_hash']);
        return redirect()->route('admin.api.owner-authorization')
            ->with('success', 'Owner Key baru berhasil dibuat. Salin sekarang; key hanya ditampilkan sekali.')
            ->with('generated_key', $key);
    }

    public function authorize(Request $request)
    {
        abort_unless($request->user() && $request->user()->root_admin, 403);
        $request->validate(['owner_key' => ['required', 'string', 'max:512']]);
        $configuredHash = $this->currentHash();
        $providedHash = hash('sha256', (string) $request->input('owner_key'));
        if ($configuredHash === '' || !preg_match('/^[a-f0-9]{64}$/', $configuredHash)
            || !hash_equals($configuredHash, $providedHash)) {
            $request->session()->forget(['protect_api_authorized', 'protect_api_authorized_user', 'protect_api_key_hash']);
            return back()->withErrors(['owner_key' => 'Owner Key tidak valid atau belum dibuat oleh Owner ID 1.']);
        }

        $request->session()->regenerate();
        $request->session()->put('protect_api_authorized', true);
        $request->session()->put('protect_api_authorized_user', (int) $request->user()->id);
        $request->session()->put('protect_api_key_hash', $configuredHash);
        return redirect()->route('admin.api.owner-authorization')->with('success', 'Sesi API berhasil diotorisasi.');
    }

    public function revoke(Request $request)
    {
        abort_unless($request->user() && $request->user()->root_admin, 403);
        $request->session()->forget(['protect_api_authorized', 'protect_api_authorized_user', 'protect_api_key_hash']);
        $request->session()->regenerateToken();
        return redirect()->route('admin.api.owner-authorization')->with('success', 'Otorisasi sesi API dicabut.');
    }
}
