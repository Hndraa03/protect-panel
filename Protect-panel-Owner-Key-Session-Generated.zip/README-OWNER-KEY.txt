PROTECT PANEL - APPLICATION API OWNER KEY SESSION

Behavior:
- Application API routes are blocked unless a logged-in root administrator has authorized the current browser session with the Owner Key.
- Only Admin ID 1 can generate or rotate the Owner Key from /admin/api-owner/authorization.
- Other root administrators can enter the Owner Key to authorize their own browser session.
- The raw key is shown only once after generation. Only its SHA-256 hash is stored in storage/app/protect-owner-key.sha256 with restrictive file permissions.
- Rotating the key invalidates all previously authorized sessions because each session stores the hash fingerprint of the active key.
- Authorization ends when the browser session expires/logs out, the user revokes it, or the Owner Key is rotated.
- Client API routes are not modified by this patcher.
- External scripts/CLI clients using only Bearer Application API tokens do not carry the browser session and will receive HTTP 403.

Setup:
1. Back up the panel.
2. Run the updated installer.
3. Run from the panel directory: php artisan optimize:clear
4. Log in as Admin ID 1 and open /admin/api-owner/authorization.
5. Click Generate Owner Key. Copy and securely store the displayed key; it is shown only once.
6. Other root admins can open the same page and enter the key to authorize their browser session.

Security notes:
- Do not commit generated keys, .env files, or storage/app/protect-owner-key.sha256 to GitHub.
- Ensure the panel web user can write to storage/app and that the directory is not publicly served.
- The installer backs up mapped files; the patcher also creates timestamped backups of routes/api-application.php and routes/web.php before modifying them.
- Keep Application API tokens secret and use least-privilege permissions.
