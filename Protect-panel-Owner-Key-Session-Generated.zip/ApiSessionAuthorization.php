<?php

namespace Pterodactyl\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/** Requires an owner-generated key approved for the current browser session. */
class ApiSessionAuthorization
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();
        if (!$user || !$user->root_admin) {
            return response()->json(['error' => 'Owner authorization required.'], 403);
        }

        $hashFile = storage_path('app/protect-owner-key.sha256');
        $currentHash = is_file($hashFile) ? trim((string) @file_get_contents($hashFile)) : '';
        $sessionHash = (string) $request->session()->get('protect_api_key_hash', '');

        if ($currentHash === ''
            || !preg_match('/^[a-f0-9]{64}$/', $currentHash)
            || !$request->session()->get('protect_api_authorized', false)
            || (int) $request->session()->get('protect_api_authorized_user') !== (int) $user->id
            || $sessionHash === ''
            || !hash_equals($currentHash, $sessionHash)) {
            return response()->json(['error' => 'Owner session authorization required.'], 403);
        }

        return $next($request);
    }
}
