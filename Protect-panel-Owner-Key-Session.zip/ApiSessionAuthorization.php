<?php

namespace Pterodactyl\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/** Requires an owner-approved browser session for Application API routes. */
class ApiSessionAuthorization
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if (!$user || !$user->root_admin) {
            return response()->json(['error' => 'Owner authorization required.'], 403);
        }

        if (!$request->session()->get('protect_api_authorized', false)
            || (int) $request->session()->get('protect_api_authorized_user') !== (int) $user->id) {
            return response()->json(['error' => 'Owner session authorization required.'], 403);
        }

        return $next($request);
    }
}
