@extends('layouts.admin')

@section('title') API Owner Authorization @endsection

@section('content-header')
    <h1>API Owner Authorization<small>Otorisasi Application API menggunakan Owner Key.</small></h1>
@endsection

@section('content')
<div class="row">
    <div class="col-xs-12">
        <div class="box box-primary">
            <div class="box-header with-border"><h3 class="box-title">Status Sesi API</h3></div>
            <div class="box-body">
                @if (session('success'))
                    <div class="alert alert-success">{{ session('success') }}</div>
                @endif
                @if ($authorized)
                    <div class="alert alert-success">Sesi browser ini sudah diotorisasi. Application API dapat digunakan sampai sesi berakhir atau otorisasi dicabut.</div>
                    <form method="POST" action="{{ route('admin.api.owner-authorization.revoke') }}">
                        {!! csrf_field() !!}
                        <button class="btn btn-danger" type="submit">Cabut Otorisasi Sesi</button>
                    </form>
                @else
                    <div class="alert alert-warning">Masukkan Owner Key untuk mengotorisasi sesi browser ini.</div>
                    <form method="POST" action="{{ route('admin.api.owner-authorization.authorize') }}">
                        {!! csrf_field() !!}
                        <div class="form-group">
                            <label for="owner_key">Owner Key</label>
                            <input id="owner_key" name="owner_key" type="password" class="form-control" required autocomplete="off">
                            @if ($errors->has('owner_key'))<span class="text-danger">{{ $errors->first('owner_key') }}</span>@endif
                        </div>
                        <button class="btn btn-primary" type="submit">Otorisasi Sesi</button>
                    </form>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection
