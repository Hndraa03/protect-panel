PROTECT PANEL - APPLICATION API OWNER KEY SESSION

Behavior:
- Application API routes are blocked unless the logged-in root administrator has authorized the current browser session with the Owner Key.
- Authorization is tied to the authenticated administrator ID and Laravel session. It ends when that browser session expires/logs out, or when the user revokes it.
- This is intentionally session-based: external scripts/CLI clients that only send a Bearer Application API token do not carry the browser session and will receive HTTP 403.
- Client API routes are not modified by this patcher.

Setup:
1. Configure a strong secret in /var/www/pterodactyl/.env:
   PROTECT_OWNER_KEY=replace-with-a-long-random-secret
2. Keep the .env file private (normally mode 640/600, owned by the panel user/root as appropriate).
3. Run the updated installer. It installs the middleware/controller/view and adds routes.
4. Run from the panel directory:
   php artisan optimize:clear
5. Log in as a root administrator, then open:
   /admin/api-owner/authorization
6. Enter the Owner Key. Application API requests made by that same browser session are then allowed.

Important:
- Take a full backup before installing. The installer already backs up mapped files, but this patcher adds/references files and modifies routes/api-application.php and routes/web.php; keep a separate copy of those route files before installation.
- The patcher deliberately stops if it cannot recognize the API route middleware declaration. It does not guess or rewrite an unknown route format.
- This is a browser-session gate, not a replacement for Pterodactyl's API token permissions. Keep API tokens secret and use least-privilege permissions.
