<?php
/** Installs session-based Owner Key protection on Application API routes. */
$panelDir = getenv('PANEL_DIR') ?: '/var/www/pterodactyl';
$middlewareSource = __DIR__ . '/ApiSessionAuthorization.php';
$controllerSource = __DIR__ . '/ApiOwnerAuthorizationController.php';
$viewSource = __DIR__ . '/views/owner-authorization.blade.php';
$configSource = __DIR__ . '/config-protect.php';
$middlewareTarget = $panelDir . '/app/Http/Middleware/ApiSessionAuthorization.php';
$controllerTarget = $panelDir . '/app/Http/Controllers/Admin/ApiOwnerAuthorizationController.php';
$viewTarget = $panelDir . '/resources/views/admin/api/owner-authorization.blade.php';
$configTarget = $panelDir . '/config/protect.php';
$apiRoutes = $panelDir . '/routes/api-application.php';
$webRoutes = $panelDir . '/routes/web.php';

foreach ([$middlewareSource, $controllerSource, $viewSource, $configSource, $apiRoutes, $webRoutes] as $file) {
    if (!is_file($file)) { fwrite(STDERR, "File wajib tidak ditemukan: {$file}\n"); exit(1); }
}

$api = file_get_contents($apiRoutes);
if (strpos($api, 'ApiSessionAuthorization::class') === false) {
    $pattern = '/(\x27middleware\x27\s*=>\s*\[)(?=[^\]]*application-api)([^\]]*)(\])/s';
    if (!preg_match($pattern, $api, $m, PREG_OFFSET_CAPTURE)) {
        fwrite(STDERR, "Tidak dapat mengenali deklarasi middleware di routes/api-application.php. Tidak ada perubahan dilakukan.\n"); exit(1);
    }
    $backupSuffix = '.protect-backup-' . date('Ymd-His');
    if (!copy($apiRoutes, $apiRoutes . $backupSuffix)) { fwrite(STDERR, "Backup API routes gagal.
"); exit(1); }
    $list = $m[2][0];
    $list .= ",\\Pterodactyl\\Http\\Middleware\\EncryptCookies::class,\\Illuminate\\Session\\Middleware\\StartSession::class,\\Pterodactyl\\Http\\Middleware\\ApiSessionAuthorization::class,";
    $replacement = $m[1][0] . $list . $m[3][0];
    $api = substr_replace($api, $replacement, $m[0][1], strlen($m[0][0]));
    $tmp = $apiRoutes . '.protect-tmp';
    file_put_contents($tmp, $api, LOCK_EX);
    rename($tmp, $apiRoutes);
}

$web = file_get_contents($webRoutes);
if (strpos($web, 'admin.api.owner-authorization') === false) {
    if (!copy($webRoutes, $webRoutes . '.protect-backup-' . date('Ymd-His'))) { fwrite(STDERR, "Backup web routes gagal.\n"); exit(1); }
    $routes = "\n// Protect Panel: session-based Owner Key authorization for Application API.\n"
        . "\\Illuminate\\Support\\Facades\\Route::middleware(['web', 'auth'])->prefix('admin/api-owner')->group(function () {\n"
        . "    \\Illuminate\\Support\\Facades\\Route::get('/authorization', [\\Pterodactyl\\Http\\Controllers\\Admin\\ApiOwnerAuthorizationController::class, 'show'])->name('admin.api.owner-authorization');\n"
        . "    \\Illuminate\\Support\\Facades\\Route::post('/authorization', [\\Pterodactyl\\Http\\Controllers\\Admin\\ApiOwnerAuthorizationController::class, 'authorize'])->name('admin.api.owner-authorization.authorize');\n"
        . "    \\Illuminate\\Support\\Facades\\Route::post('/revoke', [\\Pterodactyl\\Http\\Controllers\\Admin\\ApiOwnerAuthorizationController::class, 'revoke'])->name('admin.api.owner-authorization.revoke');\n"
        . "});\n";
    file_put_contents($webRoutes, rtrim($web) . "\n" . $routes, LOCK_EX);
}

@mkdir(dirname($middlewareTarget), 0755, true);
@mkdir(dirname($controllerTarget), 0755, true);
@mkdir(dirname($viewTarget), 0755, true);
@mkdir(dirname($configTarget), 0755, true);
foreach ([[$middlewareSource,$middlewareTarget],[$controllerSource,$controllerTarget],[$viewSource,$viewTarget],[$configSource,$configTarget]] as [$src,$dst]) {
    if (!copy($src,$dst)) { fwrite(STDERR, "Gagal memasang {$dst}\n"); exit(1); }
}

echo "Owner Key session protection berhasil dipasang.\n";
echo "Atur PROTECT_OWNER_KEY di file .env, lalu jalankan php artisan optimize:clear.\n";
echo "Halaman otorisasi: /admin/api-owner/authorization\n";
