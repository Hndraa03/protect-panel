<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Pterodactyl\Http\Controllers\Controller;

class ApiOwnerAuthorizationController extends Controller
{
    public function show(Request $request)
    {
        abort_unless($request->user() && $request->user()->root_admin, 403);
        return view('admin.api.owner-authorization', [
            'authorized' => (bool) $request->session()->get('protect_api_authorized', false),
        ]);
    }

    public function authorize(Request $request)
    {
        abort_unless($request->user() && $request->user()->root_admin, 403);

        $request->validate(['owner_key' => ['required', 'string', 'max:512']]);
        $configured = (string) config('protect.owner_key', '');
        if ($configured === '' || !hash_equals($configured, (string) $request->input('owner_key'))) {
            $request->session()->forget(['protect_api_authorized', 'protect_api_authorized_user']);
            return back()->withErrors(['owner_key' => 'Owner Key tidak valid atau belum dikonfigurasi.']);
        }

        $request->session()->regenerate();
        $request->session()->put('protect_api_authorized', true);
        $request->session()->put('protect_api_authorized_user', (int) $request->user()->id);
        return redirect()->route('admin.api.owner-authorization')->with('success', 'Sesi API berhasil diotorisasi.');
    }

    public function revoke(Request $request)
    {
        abort_unless($request->user() && $request->user()->root_admin, 403);
        $request->session()->forget(['protect_api_authorized', 'protect_api_authorized_user']);
        $request->session()->regenerateToken();
        return redirect()->route('admin.api.owner-authorization')->with('success', 'Otorisasi sesi API dicabut.');
    }
}
