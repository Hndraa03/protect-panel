<?php

return [
    // Set PROTECT_OWNER_KEY in the panel .env file.
    'owner_key' => env('PROTECT_OWNER_KEY'),
];
